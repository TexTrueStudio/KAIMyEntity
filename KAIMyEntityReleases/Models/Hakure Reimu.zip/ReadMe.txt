博丽灵梦模型，把KAIMyEntity解压到"你的minecraft数据目录"（有"mods"，"resourcepack"的那个）。
要替换其他实体，自己重命名文件夹。
模型作者：Ki。
自定义动画1作者：空虚＠せっけんP。

There are Hakure Reimu model and animations. Unzip "KAIMyEntity" to your Minecraft data folder (that has "mods", "resourcepack" folder).
To change other entities, rename folder.
Model author: Ki.
Custom animation 1 author: 空虚＠せっけんP.